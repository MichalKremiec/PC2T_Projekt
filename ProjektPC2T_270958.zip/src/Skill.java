
public interface Skill {
    void spustitDovednost();
}
